package Unit;

public enum Sprites {
    PLAYER_L,
    FISH_L;

    private Sprites() {
    }
}
