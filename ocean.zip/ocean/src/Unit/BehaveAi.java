package Unit;

import java.util.ArrayList;

public interface BehaveAi extends Behave
{
    public void behave(ArrayList<? extends Unit> unit);
}