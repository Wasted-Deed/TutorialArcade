package Unit;

public interface Movable {
    void move();

    void move(float var1, float var2);
}
