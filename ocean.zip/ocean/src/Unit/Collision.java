package Unit;

public interface Collision {
    boolean checkCollision(int x, int y);
}