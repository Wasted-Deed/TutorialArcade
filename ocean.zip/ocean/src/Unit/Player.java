package Unit;

import org.newdawn.slick.geom.Rectangle;

public class Player extends Unit {
    TypeInput input;

    public void attack() {
    }

    public Player(int health, float mWalkSpeed, Rectangle location, int damage) {
        super(health, mWalkSpeed, location, damage);
        this.input = TypeInput.None;
    }

    public TypeInput getInput() {
        return this.input;
    }

    public void setInput(TypeInput input) {
        this.input = input;
    }

    public void Control() {
        float j;
        switch(this.input.ordinal()) {
            case 1:
                this.move(this.getmWalkSpeed() / 4.0F, 0.0F);
                if (!this.isJump()) {
                    j = -this.getmJumpSpeed();
                    this.addSpeed(0.0F, j);
                    this.setJump(true);
                }
                break;
            case 2:
                this.move(-this.getmWalkSpeed() / 4.0F, 0.0F);
            case 3:
                if (!this.isJump()) {
                    j = -this.getmJumpSpeed();
                    this.addSpeed(0.0F, j);
                    this.setJump(true);
                }
                break;
            case 4:
                this.move(-this.getmWalkSpeed() / 10.0F, 0.0F);
                break;
            case 5:
                this.move(this.getmWalkSpeed() / 10.0F, 0.0F);
        }

    }

    public void behave() {
        this.Control();
        this.move();
    }
}
