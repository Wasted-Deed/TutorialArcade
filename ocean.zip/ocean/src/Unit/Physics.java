package Unit;

import org.newdawn.slick.geom.Vector2f;

import java.util.ArrayList;
import java.util.Iterator;

public class Physics {
    public Physics() {
    }

    public static void ForceGravityOnAllUnits(ArrayList<? extends Unit> unit) {
        Iterator var1 = unit.iterator();

        while(var1.hasNext()) {
            Unit CurrentUnit = (Unit)var1.next();
            if (!CurrentUnit.isOnEarth()) {
                if (CurrentUnit.getListForce().containsKey("Gravity")) {
                    CurrentUnit.addSpeed(((Vector2f)CurrentUnit.getListForce().get("Gravity")).getX() / 1000.0F, ((Vector2f)CurrentUnit.getListForce().get("Gravity")).getY() / 1000.0F);
                }
            } else {
                CurrentUnit.setJump(false);
            }
        }

    }
}