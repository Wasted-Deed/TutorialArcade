package Unit;

public interface Behave {
    void behave();
}