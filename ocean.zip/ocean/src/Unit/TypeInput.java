package Unit;

public enum TypeInput {
    L,
    R,
    R_UP,
    L_UP,
    Up,
    None;

    private TypeInput() {
    }
}