package ocean;

import org.newdawn.slick.Image;

public class Building {
	private float posX, posY;
	private Image image;
	private TypeBuilding typeBuilding;  // ��� ����������
	
	public Building(Image img, TypeBuilding type) {
		image = img;
		typeBuilding = type;
		posX = posY = -1;
	}

	public Building(Building another) {
		this.posX = another.posX;
		this.posY = another.posY;
		this.image = another.image;
		this.typeBuilding = another.typeBuilding;
	}

	public Image getImage() {
		return image;
	}

	public float getX() {
		return posX;
	}

	public float getY() {
		return posY;
	}
	
	public TypeBuilding getTypeBuilding() {
		return typeBuilding;
	}

	public void setX(float x) {
		this.posX = x;
	}

	public void setY(float y) {
		this.posY = y;
	}
}
