package ocean;

import org.newdawn.slick.Graphics;

public interface Drawable {
	void draw(Graphics g);
}
