package ocean;

public enum TypeBuilding {
	SQUARE_BLOCK,
	SPACE,
	GROUND;
}
